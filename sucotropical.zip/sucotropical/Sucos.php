<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="http://fonts.cdnfonts.com/css/abigail" rel="stylesheet">
    <link rel="stylesheet/scss" href="btstrap.scss">
    <link href='https://fonts.googleapis.com/css?family=Varela Round' rel='stylesheet'>            
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  </head>
  <style>
    @import url('http://fonts.cdnfonts.com/css/abigail');
   p{
    font-family: 'Verdana';
    color: black;
    width: 50em;
    margin: 0 4em;
    }
    .carde{
      border-radius: 50px;
      
    }
    
    
  </style>
  <body style="background-color: black;" background="casa_praia.jpg">
  
    <h1 style="color: white; font-size: 8em; text-align: center; font-family: abigail, sans-serif;">Sucos Tropicais</h1>
        <div class="card" style="border-radius: 2em; width: 59em; positon: relative; left: 5em; top: 5em; padding-top: 2em;">
      <div class="card-body carde">
      <p>Os sucos tropicais são bebidas não fermentadas obtidas pela dissolução, em água potável ou em suco clarificado de fruta tropical, da polpa de fruta de origem tropical, por meio de processo tecnológico adequado. Dentre as frutas para sucos desta categoria estão o Abacaxi, a Acerola, o Caju, a Goiaba, a Manga, o Maracujá e a Pitanga. Ricas em vitaminas, fibras e sais minerais, essas frutas possuem grande valor nutritivo.</p>
    <br>
    <p>De acordo com a legislação brasileira, o suco tropical industrializado deve ter cor, aroma e sabor característicos da fruta. Deve também ser submetido a tratamento que assegure a sua apresentação e conservação até o momento do consumo. A bebida pode também ser mista quando for produzida a partir da mistura de duas ou mais polpas de frutas de origem tropical.</p>
    <br>
    <p> Suco tropical, quando adicionado de açúcar, deverá ser denominado suco tropical, acrescido do nome da fruta e da designação adoçado, podendo ser declarado no rótulo a expressão suco pronto para beber, pronto para o consumo ou expressões semelhantes. O suco tropical também pode ser adicionado de adoçantes.</p>
    
    <br>
    <br>
    <p><b>Ingredientes obrigatórios</b></p>
    <br>

    <p>Água e suco ou polpa de fruta</p>
    <br>
    <br>
    <p><b>Ingredientes opcionais normalmente utilizados</b></p>
    <br>
    <p>Açúcar ou edulcorantes, aromas, acidulantes, corantes naturais e antioxidantes.</p>
    <br>

    <br>
    <br>
    <br>

    <h2 style="color: red; text-align: center;">Mitos e Verdades sobre os sucos tropicais</h2>
    <br>
    <br>

    <p><b>O consumo de sucos tropicais pode prejudicar a saúde?</b></p>
    <p style="color: red;"><b>MITO</b></p>
    <p>Os sucos tropicais têm sua segurança e controle de qualidade regidos e atestados rigorosamente por autoridades e podem ser consumidos sem prejuízo algum à saúde.</p>
    <br>
    <p><b>Os sucos tropicais comercializados contêm em sua composição realmente as frutas que informam ter?</b></p>
    <p style="color: green;"><b>Verdade</b></p>
    <p>Confira a quantidade mínima de suco da fruta nos sucos tropicais estabelecida pela legislação brasileira:</p>

    <ul style="display: inline-block; position: relative; left: 16em; color: black;">
    <li>Abacaxi: 60% não adoçado e 50% adoçado</li>
    <li>Acerola: 60% não adoçado e 35% adoçado</li>
    <li>Cajá: 50% não adoçado e 35% adoçado</li>
    <li>Goiaba: 50% não adoçado e 45% adoçado</li>
    <li>Manga: 60% não adoçado e 50% adoçado</li>
    <li>Maracujá: 50% não adoçado e 12% adoçado</li>
  </ul>
<br>
<br>
<p><b>As frutas presentes nos sucos tropicais perdem seu valor nutritivo após o preparo do suco?</b></p>
<p style="color: red;"><b>MITO</b></p>
<p> O suco mantém as mesmas propriedades (vitaminas, minerais, fibras, etc.) do que a fruta antes do preparo. Sendo assim, os sucos tropicais são uma importante fonte nutricional.</p>
<br>
<p><b>Os sucos tropicais possuem conservadores em sua composição?</b></p>
<p>Devido ao rápido avanço tecnológico no envase de bebidas, o uso dos conservadores tem sido dispensado. O processo de envase em embalagens longa vida ou PET, por exemplo, possibilitam a inocuidade das bebidas sem a adição dessas substâncias.</p>  

      </div>
    </div>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
  </body>
</html>